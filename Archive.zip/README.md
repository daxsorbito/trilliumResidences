# Trillium Residences
A static website using GSAP and ScrollMagic

## How to run
1. ```$ npm i -g browser-sync ```
2. ```$ browser-sync start --server --files "*" --files "*/*" ```
